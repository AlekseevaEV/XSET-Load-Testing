Action()
{
	lr_start_transaction("UC3_BuyTickets");
	
	open_home_page();
	
	login();
	
	click_flights();

	select_flight();
	
	lr_start_transaction("reservation");

			web_reg_find("Text/IC=Flight Reservation",
				LAST);
	
			web_reg_find("Text/IC={outboundFlight}",
				LAST);
	
			web_find("Text/IC=Flight departing from <B>{departCities}</B> to <B>{arriveCities}</B> on <B>{departDate}</B>",
				LAST);
	

			web_submit_data("reservations.pl_2",
				"Action=http://localhost:1080/cgi-bin/reservations.pl",
				"Method=POST",
				"TargetFrame=",
				"RecContentType=text/html",
				"Referer=http://localhost:1080/cgi-bin/reservations.pl",
				"Snapshot=t5.inf",
				"Mode=HTML",
				ITEMDATA,
				"Name=outboundFlight", "Value={outboundFlight}", ENDITEM,
				"Name=numPassengers", "Value=1", ENDITEM,
				"Name=advanceDiscount", "Value=0", ENDITEM,
				"Name=seatType", "Value={seatType}", ENDITEM,
				"Name=seatPref", "Value={seatPref}", ENDITEM,
				"Name=reserveFlights.x", "Value=41", ENDITEM,
				"Name=reserveFlights.y", "Value=4", ENDITEM,
				LAST);

			
	lr_end_transaction("reservation", LR_AUTO);
	
	lr_think_time(5);
	
	lr_start_transaction("payment_details");
	
			web_reg_find("Text/IC=Reservation Made!",
	             LAST);
	
			web_find("Text/IC/DIG=Total for # ticket(s) is = $ ####",
		LAST);

			web_find("Text/IC=A {seatType} Class ticket from {departCities} to {arriveCities}",
				LAST);
		

			web_revert_auto_header("Origin");		
			web_revert_auto_header("Sec-Fetch-User");		
			web_revert_auto_header("Upgrade-Insecure-Requests");		
			web_add_auto_header("Origin", "http://localhost:1080");	
			web_submit_data("reservations.pl_3",
				"Action=http://localhost:1080/cgi-bin/reservations.pl",
				"Method=POST",
				"TargetFrame=",
				"RecContentType=text/html",
				"Referer=http://localhost:1080/cgi-bin/reservations.pl",
				"Snapshot=t6.inf",
				"Mode=HTML",
				ITEMDATA,
				"Name=firstName", "Value={firstName}", ENDITEM,
				"Name=lastName", "Value={lastName}", ENDITEM,
				"Name=address1", "Value={address1}", ENDITEM,
				"Name=address2", "Value={address2}", ENDITEM,
				"Name=pass1", "Value={firstName} {lastName}", ENDITEM,
				"Name=creditCard", "Value={creditCard}", ENDITEM,
				"Name=expDate", "Value=01/30", ENDITEM,
				"Name=saveCC", "Value=on", ENDITEM,
				"Name=oldCCOption", "Value=on", ENDITEM,
				"Name=numPassengers", "Value=1", ENDITEM,
				"Name=seatType", "Value={seatType}", ENDITEM,
				"Name=seatPref", "Value={seatPref}", ENDITEM,
				"Name=outboundFlight", "Value={outboundFlight}", ENDITEM,
				"Name=advanceDiscount", "Value=0", ENDITEM,
				"Name=returnFlight", "Value=", ENDITEM,
				"Name=JSFormSubmit", "Value=off", ENDITEM,
				"Name=buyFlights.x", "Value=18", ENDITEM,
				"Name=buyFlights.y", "Value=11", ENDITEM,
				"Name=.cgifields", "Value=saveCC", ENDITEM,
				LAST);
			
	lr_end_transaction("payment_details", LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("Invoice");
	
			web_find("Text=<b>{firstName}{lastName}'s Flight Invoice</b>",
				LAST);

			web_find("Text=Total Charged to Credit Card # {creditCard}",
				LAST);

			web_add_auto_header("Sec-Fetch-User", "?1");
			web_add_auto_header("Upgrade-Insecure-Requests", "1");
			web_submit_data("reservations.pl_4", 
				"Action=http://localhost:1080/cgi-bin/reservations.pl", 
				"Method=POST", 
				"TargetFrame=", 
				"RecContentType=text/html", 
				"Referer=http://localhost:1080/cgi-bin/reservations.pl", 
				"Snapshot=t7.inf", 
				"Mode=HTML", 
				ITEMDATA, 
				"Name=Book Another.x", "Value=39", ENDITEM, 
				"Name=Book Another.y", "Value=10", ENDITEM, 
				LAST);

	lr_end_transaction("Invoice", LR_AUTO);

	lr_think_time(5);
	
	lr_start_transaction("click_itinerary");
	
			web_reg_find("Text/IC=User wants the intineraries",
						LAST);
	
			web_find("Text/IC=<b>{firstName} {lastName}'s Flight Transaction Summary</b>",
				LAST);

			web_revert_auto_header("Origin");
			web_revert_auto_header("Sec-Fetch-User");		
			web_revert_auto_header("Upgrade-Insecure-Requests");		
			web_url("Itinerary Button", 
				"URL=http://localhost:1080/cgi-bin/welcome.pl?page=itinerary", 
				"TargetFrame=body", 
				"Resource=0", 
				"RecContentType=text/html", 
				"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=flights", 
				"Snapshot=t8.inf", 
				"Mode=HTML", 
				LAST);
			
	lr_end_transaction("click_itinerary", LR_AUTO);

	lr_think_time(5);
	
	sigh_off();

	lr_end_transaction("UC3_BuyTickets", LR_AUTO);

	return 0;
}