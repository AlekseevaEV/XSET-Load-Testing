Action()
{	
	lr_start_transaction("UC5_DeleteTicket");

	web_set_sockets_option("SSL_VERSION", "AUTO");
	
	open_home_page();
	
	login();
	
	lr_start_transaction("click_itinerary");
	
			web_reg_find("Text/IC=User wants the intineraries",
	             LAST);
	
			web_find("Text/IC=<b>{firstName} {lastName}'s Flight Transaction Summary</b>",
				LAST);

	
		web_reg_save_param("flightID",
			"LB/IC=flightID\" value=\"",
			"RB/IC=\"",
			LAST);
	
			web_add_auto_header("Sec-Fetch-User", "?1");
			web_add_auto_header("Upgrade-Insecure-Requests", "1");
			web_url("Itinerary Button", 
				"URL=http://localhost:1080/cgi-bin/welcome.pl?page=itinerary", 
				"TargetFrame=body", 
				"Resource=0", 
				"RecContentType=text/html", 
				"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
				"Snapshot=t7.inf", 
				"Mode=HTML", 
				LAST);
	
		
	lr_end_transaction("click_itinerary",LR_AUTO);

	lr_think_time(5);
	
	lr_start_transaction("delete_flight");
	
	
	web_reg_find("Fail=Found","Text/IC={flightID}",
		LAST);

			web_add_header("Origin", 
				"http://localhost:1080");
	
	web_submit_form("itinerary.pl",
	           "Snapshot=t9.inf",
				ITEMDATA,
				"Name=1", "Value=on", ENDITEM,
				"Name=removeFlights.x", "Value=52", ENDITEM, 
				"Name=removeFlights.y", "Value=8", ENDITEM, 
				LAST);
		
	
	lr_end_transaction("delete_flight",LR_AUTO);

	lr_think_time(5);
	
	sigh_off();

	lr_end_transaction("UC5_DeleteTicket", LR_AUTO);

	return 0;
}