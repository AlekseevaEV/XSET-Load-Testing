Action()
{
	
	lr_start_transaction("UC6_Registration");

	open_home_page();
	
	lr_start_transaction("click_sign_up");
		
		web_reg_find("Text/IC=<b>First time registering? Please complete the form below.</b>",
				LAST);

		web_add_auto_header("Sec-Fetch-User","?1");
		web_url("login.pl", 
			"URL=http://localhost:1080/cgi-bin/login.pl?username=&password=&getInfo=true", 
			"TargetFrame=body", 
			"Resource=0", 
			"RecContentType=text/html", 
			"Referer=http://localhost:1080/WebTours/home.html", 
			"Snapshot=t2.inf", 
			"Mode=HTML", 
			LAST);
		

	lr_end_transaction("click_sign_up", LR_AUTO);
		
	lr_think_time(31);
	
	lr_start_transaction("user_profile");
	
			web_reg_find("Text/IC=Your password is invalid.  Please re-enter it and it's confirmation.",
				LAST);
			
			web_find("Text/IC=Thank you, <b>{username}</b>, for registering",
				LAST);			
	
			web_add_header("Origin", "http://localhost:1080");
			web_submit_data("login.pl_2", 
				"Action=http://localhost:1080/cgi-bin/login.pl", 
				"Method=POST", 
				"TargetFrame=info", 
				"RecContentType=text/html", 
				"Referer=http://localhost:1080/cgi-bin/login.pl?username=&password=&getInfo=true", 
				"Snapshot=t3.inf", 
				"Mode=HTML", 
				ITEMDATA, 
				"Name=username", "Value={username}", ENDITEM, 
				"Name=password", "Value={password}", ENDITEM, 
				"Name=passwordConfirm", "Value={password}", ENDITEM, 
				"Name=firstName", "Value=", ENDITEM, 
				"Name=lastName", "Value=", ENDITEM, 
				"Name=address1", "Value=", ENDITEM, 
				"Name=address2", "Value=", ENDITEM, 
				"Name=register.x", "Value=81", ENDITEM, 
				"Name=register.y", "Value=4", ENDITEM, 
				LAST);

	lr_end_transaction("user_profile", LR_AUTO);

			
	lr_think_time(20);		

	lr_start_transaction("click_continue");
	
		web_find("Text/IC=Welcome, <b>{username}</b>, to the Web Tours reservation pages",
						LAST);

		web_revert_auto_header("Sec-Fetch-User");
		web_add_auto_header("Sec-Fetch-User", "?1");
		web_url("button_next.gif", 
			"URL=http://localhost:1080/cgi-bin/welcome.pl?page=menus", 
			"TargetFrame=body", 
			"Resource=0", 
			"RecContentType=text/html", 
			"Referer=http://localhost:1080/cgi-bin/login.pl", 
			"Snapshot=t4.inf", 
			"Mode=HTML", 
			LAST);

	lr_end_transaction("click_continue", LR_AUTO);

	lr_think_time(18);
	
	sigh_off();

	lr_end_transaction("UC6_Registration", LR_AUTO);

	return 0;
}