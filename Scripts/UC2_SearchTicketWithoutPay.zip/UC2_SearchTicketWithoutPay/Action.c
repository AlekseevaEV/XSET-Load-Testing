Action()
{

	lr_start_transaction("UC2_SearchTicketWithoutPay");

	open_home_page();
		
	login();
		
	click_flights();
	
	select_flight();

	sigh_off();

	lr_end_transaction("UC2_SearchTicketWithoutPay", LR_AUTO);


	return 0;
}