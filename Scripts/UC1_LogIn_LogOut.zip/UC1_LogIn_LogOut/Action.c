Action()
{

	lr_start_transaction("UC1_LogIn_LogOut");

	web_set_sockets_option("SSL_VERSION", "AUTO");
	
	open_home_page();

	login();
	
	sigh_off();

	lr_end_transaction("UC1_LogIn_LogOut", LR_AUTO);

	return 0;
}